import Zero
import Events
import VectorMath

class ModelHider:
    def Execute(self, Editor):
        for cog in Editor.EditSpace.AllObjects():
            if(cog.Model):
                cog.Model.Visible = True
        
        

Zero.RegisterCommand("ModelHider", ModelHider)